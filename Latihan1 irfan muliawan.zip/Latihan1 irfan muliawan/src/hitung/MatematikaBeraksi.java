package hitung;

public class MatematikaBeraksi {
    public static void main(String[] args){
        Matematika Irfan = new Matematika();
        
        Irfan.Pertambahan(5, 8);
        Irfan.Pengurangan(5, 8);
        Irfan.Perkalian(5, 8);
        Irfan.Pembagian(5, 8);
        
    }
    
}
